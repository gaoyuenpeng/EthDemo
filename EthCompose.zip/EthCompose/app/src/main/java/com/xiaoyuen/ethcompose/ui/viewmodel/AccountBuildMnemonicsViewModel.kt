package com.xiaoyuen.ethcompose.ui.viewmodel

import android.content.Context

class AccountBuildMnemonicsViewModel(context: Context) : BaseViewModel(context) {

}