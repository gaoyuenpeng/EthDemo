package com.xiaoyuen.ethcompose.compose

import androidx.ui.graphics.Color

val MainBlue = Color(0xFF1296db)
val TextBlack = Color(0xff333333)
val MainGrey = Color(0xFFededed)
val TextGreyF3 = Color(0xFFf3f3f3)
val TextGreyHint = Color(0xFF6e6e6e)
val TextTabNormal = Color(0xFFbfbfbf)

