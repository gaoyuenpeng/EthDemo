package com.xiaoyuen.ethcompose.base

object Config {
    const val keyAddress = "ethereum:"//钱包地址key
    const val keyValue = "value="//转账金额key
}